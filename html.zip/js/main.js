(function($) {

    'use strict';        

        $(window).load(function() {

            // PRELOADER
            //$('#preloader').fadeOut('slow',function(){$(this).remove();});            
                
            // FEATURED SLIDER HOMEPAGE
            $('.slider').flexslider({
                animation: "slide",
                controlNav: false,
                directionNav: false,
                smoothHeight : true,
            });

            // TESTIMONIAL HOMEPAGE
            $('.testimonial').flexslider({
                animation: "slide",
                controlNav: true,
                directionNav: false,
                smoothHeight : true,
            }); 

            // PROJECT SLIDER
            $('#bigimage').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,
                fade: false,
                asNavFor: '#thumbnail'
            });
            $('#thumbnail').slick({
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: true,
                asNavFor: '#bigimage',
                verticalSwiping: true,
                vertical: true,
                focusOnSelect: true
            });          

            var $containerGal = $('.portfolio-list');
            $containerGal.isotope({
                filter: '*',
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                }
            });
         
            $('.portfolio .sorting button').click(function(){
                $('.portfolio .sorting .current').removeClass('current');
                $(this).addClass('current');
         
                var selector = $(this).attr('data-filter');
                $containerGal.isotope({
                    filter: selector,
                    animationOptions: {
                        duration: 750,
                        easing: 'linear',
                        queue: false
                    }
                 });
                 return false;
            });             
            
        });      


        $(document).ready(function(){   
            $('#bigimage').magnificPopup({
                delegate: 'a', // child items selector, by clicking on it popup will open
                type: 'image',
                closeOnContentClick: false,
                closeBtnInside: false,
                mainClass: 'mfp-with-zoom mfp-img-mobile',
                gallery: {
                    enabled: true
                },
                zoom: {
                    enabled: true,
                    duration: 300, // don't foget to change the duration also in CSS
                    opener: function(element) {
                        return element.find('img');
                    }
                }
                // other options
            });                
        });
             

})( jQuery );